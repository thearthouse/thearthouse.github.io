<?php 
    require_once('includes/functions.php');
    display_last_run();

?>