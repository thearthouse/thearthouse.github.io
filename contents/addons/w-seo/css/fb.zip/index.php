<?php
// Initialize the session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
    header("Content-Type: text/html; charset=utf-8");
}
error_reporting(0);
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ./login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/fonts.css">
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/myjs.js"></script>
    <title>Gh_Matic</title>
    <link rel="shortcut icon" href="./favicon.ico" type="image/x-icon">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
</head>
<body class="bg-dark">

<div class="container-fluid">
    <div class="row">
      <div class="col">
          <div class="card mt-5">
            <div class="card-title">
                <div class="row ml-3 mr-3 mt-2">
                    <div class="col-md-9">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#Registration">Add New</button>
                    </div>
                    <div class="col mt-auto mb-auto" style="text-align: right;">
                        <span class="badge badge-info" id="botrunned" style="font-size: 0.9em;"></span> 
                    </div>
                </div>
                <div class="row ml-3 mr-3 mt-2">
                                    <div class="col-md-10"></div>
                                    <div class="col mt-auto mb-auto" style="text-align: right;">
                                        <select class="form-control form-control-sm" id="man_select" onchange="view_record()">
                                                <option selected value="2">Actives</option>
                                                <option value="1">Disabled</option>
                                                <option value="0">All</option>
                                         </select> 
                                    </div>
                </div>
            </div>
            <div class="card-body">
                <div id="table"></div>
            </div>
          </div>
        </div>
      </div>

    </div>

    <!--Registration Modal-->
    <div class="modal" id="Registration">
      <div class="modal-dialog modal-lg">
        <div class="modal-content" style="background-color: #f3f3f3;">
          <div class="modal-header">
            <h3 class="text-dark">Add New Record</h3>
          </div>
          <div class="modal-body">
          <p id="message" class=""></p>
            <form autocomplete="off">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="gh_uname_add"><strong>Gh Username: a/b<span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control"  id="gh_uname_add">
                </div>
                <div class="form-group col-md-3">
                    <label for="gh_mail_add"><strong>Gh Mail: <span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control" id="gh_mail_add">
                </div>
                <div class="form-group col-md-4">
                    <label for="gh_token_add"><strong>Gh Token: <span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control" id="gh_token_add">
                </div>
                <div class="form-group col">
                    <label for="gh_branch_add"><strong>Gh Branch: <span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control" id="gh_branch_add" value="main">
                </div>
                <div class="form-group col-md-3 d-none">
                    <label for="wb_name_add"><strong>Firebase Name:</strong></label>
                    <input type="text" class="form-control"  id="wb_name_add">
                </div>
                <div class="form-group col-md-3 d-none">
                    <label for="wb_clientid_add"><strong>Wb Clientid:</strong></label>
                    <input type="text" class="form-control"  id="wb_clientid_add">
                </div>
                <div class="form-group col-md-3 d-none">
                    <label for="wb_clientsecret_add"><strong>Wb Clientsecret:</strong></label>
                    <input type="text" class="form-control"  id="wb_clientsecret_add">
                </div>
                <div class="form-group col-md-4">
                    <label for="wb_apikey_add"><strong>Wb Apikey: <span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control"  id="wb_apikey_add">
                </div>
                <div class="form-group col">
                    <label for="gh_sitemap_limit_add"><strong>Sitemap limit: <span class="text-danger ">*</span></strong></label>
                    <input type="number" class="form-control" id="gh_sitemap_limit_add" value="150">
                </div>
                <div class="form-group col">
                    <label for="gh_shedule_add"><strong>Gh Shedule x min: <span class="text-danger ">*</span></strong></label>
                    <input type="number" class="form-control" id="gh_shedule_add" value="5">
                </div>
                <div class="form-group col">
                    <label for="wb_shedule_add"><strong>Wb Shedule x min: <span class="text-danger ">*</span></strong></label>
                    <input type="number" class="form-control" id="wb_shedule_add" value="360">
                </div>
              </div>
                <div class="form-row">
                    <div class="form-group col-md-3">
                        <label for="path_mode"><strong>Path Mode:</strong></label>
                        <select class="form-control" id="path_mode">
                            <option value="md" selected>Md</option>
                            <option value="html">Html</option>
                        </select>
                    </div>
                </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-success" id="btn_register">Add Now</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal" id="btn_close">Close</button>
          </div>
        </div>
      </div>
    </div>

    <!--Update Modal-->
     <div class="modal" id="update">
      <div class="modal-dialog modal-lg">
        <div class="modal-content" style="background-color: #f3f3f3;">
          <div class="modal-header">
            <h3 class="text-dark">Update Record</h3>
          </div>
          <div class="modal-body">
          <p id="up-message" class=""></p>
            <form autocomplete="off">
            <div class="form-row">
                <input type="hidden" class="form-control my-2" placeholder="uid" id="Up_User_ID">
                <div class="form-group col-md-3">
                    <label for="gh_uname_edit"><strong>Gh Username: <span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control"  id="gh_uname_edit">
                </div>
                <div class="form-group col-md-3">
                    <label for="gh_mail_edit"><strong>Gh Mail: <span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control" id="gh_mail_edit">
                </div>
                <div class="form-group col-md-4">
                    <label for="gh_token_edit"><strong>Gh Token: <span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control" id="gh_token_edit">
                </div>
                <div class="form-group col">
                    <label for="gh_branch_edit"><strong>Gh Branch: <span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control" id="gh_branch_edit">
                </div>
                <div class="form-group col-md-3">
                    <label for="wb_name_edit"><strong>Firebase Name: <span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control"  id="wb_name_edit">
                </div>
                <div class="form-group col-md-3">
                    <label for="wb_clientid_edit"><strong>Wb Clientid: <span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control"  id="wb_clientid_edit">
                </div>
                <div class="form-group col-md-3">
                    <label for="wb_clientsecret_edit"><strong>Wb Clientsecret: <span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control"  id="wb_clientsecret_edit">
                </div>
                <div class="form-group col-md-3">
                    <label for="wb_apikey_edit"><strong>Wb Apikey: <span class="text-danger ">*</span></strong></label>
                    <input type="text" class="form-control"  id="wb_apikey_edit">
                </div>
                <div class="form-group col-md-8">
                    <label for="wb_token_edit"><strong>Wb Token: </strong></label>
                    <input type="text" class="form-control"  id="wb_token_edit">
                </div>
                <div class="form-group col">
                    <label for="gh_sitemap_limit_edit"><strong>Sitemap limit: <span class="text-danger ">*</span></strong></label>
                    <input type="number" class="form-control" id="gh_sitemap_limit_edit">
                </div>
                <div class="form-group col-md-3">
                    <label for="gh_shedule_edit"><strong>Gh Shedule x min: <span class="text-danger ">*</span></strong></label>
                    <input type="number" class="form-control" id="gh_shedule_edit">
                </div>
                <div class="form-group col-md-3">
                    <label for="wb_shedule_edit">Wb Shedule x min: <span class="text-danger font-weight-bold">*</span></label>
                    <input type="number" class="form-control" id="wb_shedule_edit">
                </div>
                <div class="form-group col-md-3">
                    <label for="theme_clonned_edit"><strong>Theme Clonned:</strong></label>
                    <input type="text" class="form-control"  id="theme_clonned_edit">
                </div>
                <div class="form-group col-md-3">
                    <label for="activated_edit"><strong>Active:</strong></label>
                    <select class="form-control" id="activated_edit">
                        <option value="1">Active</option>
                        <option value="0">Disabled</option>
                    </select>
                </div>
             </div>
                <div class="form-row">
                    <div class="form-group col-md-3">
                        <label for="path_mode_edit"><strong>Path Mode:</strong></label>
                        <select class="form-control" id="path_mode_edit">
                            <option value="md">Md</option>
                            <option value="html">Html</option>
                        </select>
                    </div>
                </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-success" id="btn_update">Update Now</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal" id="btn_close">Close</button>
          </div>
          <strong><span class="text-danger ">&nbsp;&nbsp;*&nbsp;</span>normal mode = empty</strong>
          <strong><span class="text-danger ">&nbsp;&nbsp;*&nbsp;</span>post mode = poster-post,</strong>
          <strong><span class="text-danger ">&nbsp;&nbsp;*&nbsp;</span>index_fast = index_fast, uses index api</strong>
           <strong><span class="text-danger ">&nbsp;&nbsp;++&nbsp;</span>uses Google Search Console API </strong>
           <strong><span class="text-danger ">&nbsp;&nbsp;++&nbsp;</span>uses YouTube Data API v3  </strong>
           <strong><span class="text-danger ">&nbsp;&nbsp;++&nbsp;</span>uses Indexing API  if index_fast enabled </strong>
        </div>
      </div>
    </div>

    <!--Delete Modal-->
    <!--Update Modal-->
    <div class="modal" id="delete">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h3 class="text-dark">Delete Record</h3>
          </div>
          <div class="modal-body">
          <p id="delete-message" class=""></p>
            <p id="drmmuss" > Do You Want to Delete the Record ?</p>
            <button type="button" class="btn btn-success" id="btn_delete_record">Delete Now</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal" id="btn_close">Close</button>
          </div>
        </div>
      </div>
    </div>
   
<div class="container-fluid">
    <div class="row">
      <div class="col">
          <div class="card mt-5">
            <div class="card-body">
                <div class="form-group ml-1 mr-1">
                    <div class="form-row">
                        <div class="form-group col">
                            <label for="comment"><strong>Logs:</strong></label>
                        </div>
                        <div class="form-group col-md-1">
                            <select class="form-control form-control-sm" id="logs_opt" onchange="view_record()">
                                <option selected value="1">All</option>
                                <option value="0">Error</option>
                            </select>
                        </div>
                        
                    </div>
                    <div class="form-control" id="loggerd" readonly></div>
                </div>
                <p class="d-none" id="logskaz" ></p>
                <button type="button" class="btn btn-success" id="btn_delete_logs">Clear log</button>
                    
            </div>
          </div>
        </div>
      </div>
</div> 
</body>
</html>