<?php 

    require_once('includes/functions.php');
    get_record();

?>