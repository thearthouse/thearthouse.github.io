import requests

repo_name = "buffynsto.github.io"
repo_owner = "buffynsto"
token = "8685af6e553bf7274459647af5584596990d1712"

query = """
query {
  repository(name: \"""" + repo_name + """\", owner: \"""" + repo_owner + """\") {
    refs(refPrefix: "refs/heads/", first: 100) {
      nodes {
        id
        name
      }
    }
  }
}
"""

resp = requests.post('https://api.github.com/graphql', 
    json={ "query": query},
    headers= {"Authorization": f"Token {token}"}
)
body = resp.json()

for i in body["data"]["repository"]["refs"]["nodes"]:
    print(i["name"], i["id"])

chosenBranchId = input("Enter a branch ID: ")

query = """
mutation {
  deleteRef(input: {refId: \"""" + chosenBranchId + """\"}) {
    __typename
    clientMutationId
  }
}
"""

resp = requests.post('https://api.github.com/graphql', 
    json={ "query": query},
    headers= {"Authorization": f"Token {token}"}
)
print(resp.json())