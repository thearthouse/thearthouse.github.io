<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
    header("Content-Type: text/html; charset=utf-8");
}
/* error_reporting(0);
// Check if the user is logged in, if not then redirect him to login page */
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ./login.php");
    exit;
}
    require_once('connection.php');

    // Insert Record Function
    function InsertRecord()
    {
        global $db;
        $gh_uname = trim($_POST['gh_uname']);
        $gh_mail = trim($_POST['gh_mail']);
        $gh_token = trim($_POST['gh_token']);
        $gh_branch = trim($_POST['gh_branch']);
        $wb_name = trim($_POST['wb_name']);
        $wb_clientid = trim($_POST['wb_clientid']);
        $wb_clientsecret = trim($_POST['wb_clientsecret']);
        $wb_apikey = trim($_POST['wb_apikey']);
        $gh_sitemap_limit = trim($_POST['gh_sitemap_limit']);
        $gh_shedule = trim($_POST['gh_shedule']);
        $wb_shedule = trim($_POST['wb_shedule']);
        $path_moden = trim($_POST['path_mode']);
        $result = $db->exec("INSERT INTO parts(id,gh_uname,gh_mail,gh_token,gh_branch,wb_name,wb_clientid,wb_clientsecret,wb_apikey,wb_token,wb_shedule,gh_shedule,sitemap_limit,gh_last,gh_next,wb_last_execute,wb_next_execute,theme_clonned,total_sitemap,activated,path_mode) values(null,'$gh_uname','$gh_mail','$gh_token','$gh_branch','$wb_name','$wb_clientid','$wb_clientsecret','$wb_apikey','',$wb_shedule,$gh_shedule,$gh_sitemap_limit,0,0,0,0,'',0,1,'$path_moden')");
        //$result = $db->exec("INSERT INTO parts(id,gh_uname) values(null,'$gh_uname')");
        //$db->exec("INSERT INTO video(videoid) VALUES('$content')");
        if($result)
        {   
            $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$gh_uname','added','success',".time().")");
            echo ' <span class="badge badge-success">Your Record '.$gh_uname.' Has Been Saved in the Database</span>';
        }
        else
        {
            echo ' <span class="badge badge-danger">Please Check Your Query. '.$db->lastErrorMsg().'</span> ';
        }
    }

    // Display Data Function
    function display_record()
    {
        global $db;
        $lselect = $_POST['man_select'];
        $value = "";
        $value = '<table class="table table-bordered">
                    <tr>
                        <td><strong>No</strong></td>
                        <td><strong>Gh Uname</strong></td>
                        <td><strong>Gh Mail</strong></td>
                        <td><strong>Branch</strong></td>
                        <td><strong>Smap Limit</strong></td>
                        <td><strong>Post shedule</strong></td>
                        <td><strong>Post Last</strong></td>
                        <td><strong>Wb Last</strong></td>
                        <td><strong>Smap Tot</strong></td>
                        <td><strong> Edit </strong></td>
                        <td><strong> Delete </strong></td>
                        <td><strong> Status </strong></td>
                    </tr>';
        if($lselect == 0){
            $query = "select * from  parts ";
        }
        if($lselect == 1){
            $query = "select * from  parts WHERE activated = 0";
        }
        if($lselect == 2){
            $query = "select * from  parts WHERE activated = 1";
        }
        $result = $db->query($query);
        $bno = 1;
        while($row= $result->fetchArray())
        {
            if(empty($row['theme_clonned']) || strpos($row['theme_clonned'], 'poster-post') !== false && strpos($row['theme_clonned'], 'done') === false){
                $estra = '<a href="./includes/clone.php?user='.$row['gh_uname'].'" target="_blank"><i class="fas fa-eye " style="font-size:35px;color:#d43838" title = "update logo.png then clone"></i></a>';
            }else if(!empty($row['theme_clonned']) && strpos($row['theme_clonned'], 'done') === false){
                $estra = '<i class="fas fa-eye " style="font-size:35px;color:#d43838" title = "please update theme_clonned to done, external theme name"></i>';
            }else if(empty($row['wb_name']) || empty($row['wb_clientid']) || empty($row['wb_clientsecret']) || empty($row['wb_apikey'])){
                $estra = '<i class="fas fa-eye" style="font-size:35px;color:#d43838" title = "Webmaster not full filled"></i>';
            }else if(empty($row['wb_token'])){
                $estra = '<a href="./includes/auth.php?user='.$row['gh_uname'].'" target="_blank"><i class="fas fa-eye" style="font-size:35px;color:#d43838" title = "Get Outh!"></i></a>';
            }else {
                $estra = '<i class="fas fa-eye" style="font-size:35px;color:green" title = "Good!"></i>';
            }
            $color_disabled = "";
            if(strpos($row['theme_clonned'], 'label') !== false){
                preg_match('/label:(.*?),/i', $row['theme_clonned'], $sults);
                 $color_disabled = $sults[1];
            }
            if($row['activated'] == 0){
                 $estra = '<i class="fas fa-eye-slash" style="font-size:35px;color:black" title = "Disabled"></i>';
                 $color_disabled = "#ffdddd";
            }
            
            $uSERR = $row['gh_uname'];
            $videos_id_total = $row['total_vid']; //$db->querySingle("SELECT count(*) FROM vids WHERE user = '$uSERR'");
            $videos_id_total_update = $row['updated_vid']; //$db->querySingle("SELECT count(*) FROM vids WHERE (status != '' OR status IS NOT NULL) AND user = '$uSERR'");
            $videos_id_total_not_update = $videos_id_total - $videos_id_total_update;   //$db->querySingle("SELECT count(*) FROM vids WHERE (status = '' OR status IS NULL) AND user = '$uSERR'");
            $vid_cal='';
            if($videos_id_total_not_update > 0){
                $vid_cal=' <sup><span class="badge badge-pill badge-info">'.$videos_id_total_not_update.'</span></sup>';
            }
            $value.= ' <tr style="background-color: '.$color_disabled.';">
                            <td> '.$bno.' </td>
                            
                            <td title = "Vids Total = '.$videos_id_total.'&#013;Updated = '.$videos_id_total_update.'&#013;Not updated = '.$videos_id_total_not_update.'"> '.$row['gh_uname'].''.$vid_cal.'</td>
                            <td> '.$row['gh_mail'].'</td>
                            <td> '.$row['gh_branch'].'</td>
                            <td> '.$row['sitemap_limit'].'</td>
                            <td> '.$row['gh_shedule'].'</td>
                            <td title = "Next : '.($row['gh_next'] == 0 ? '-' : date("Y-m-d H:i:s", $row['gh_next'])).'">'.
                            ($row['gh_last'] == 0 ? '-' : 
                            (floor(((time() - $row['gh_last'])/60)) >= 60 ? 
                                floor(((time() - $row['gh_last'])/60)).' <span style="color:red">min ago</span>' : 
                                    floor(((time() - $row['gh_last'])/60)).' min ago')
                            ).'</td>
                            
                            <td title = "Next : '.($row['wb_next_execute'] == 0 ? '-' : date("Y-m-d H:i:s", $row['wb_next_execute'])).'"> '.
                            ($row['wb_last_execute'] == 0 ? '-' : 
                            (floor(((time() - $row['wb_last_execute'])/60)) >= 1000 ? 
                                floor(((time() - $row['wb_last_execute'])/60)).' <span style="color:red">min ago</span>' : 
                                    floor(((time() - $row['wb_last_execute'])/60)).' min ago')
                            ).'</td>
                            <td> '.$row['total_sitemap'].'</td>
                            <td> <button class="btn btn-success" id="btn_edit" data-id='.$row['id'].'><span class="fa fa-edit"></span></button> </td>
                            <td> <button class="btn btn-danger" id="btn_delete" data-id1='.$row['id'].' data-id2="'.$row['gh_uname'].'"><span class="fa fa-trash"></span></button> </td>
                            <td> '.$estra.'</i></td>
                        </tr>';
                        $bno += 1;
        }
        $value.='</table>';
        echo json_encode(['status'=>'success','html'=>$value]);
    }

   // Display Data Function
    function display_logs()
    {
        global $db;
        $plog = $_POST['logger'];
        $value = "";
        if($plog > 0){
            $query = "select * from logs ORDER BY id DESC limit 50";
        }else{
            $query = "select * from logs where type='error' ORDER BY id DESC limit 50";
        }
        $result = $db->query($query);
        while($row= $result->fetchArray())
        {
            
            $value.= date("Y-m-d H:i:s", $row['date']);
            if($row['type'] == "error"){
              $value.= '&nbsp;&nbsp;<span class="badge badge-danger col-md-0.1">&nbsp;&nbsp;'.$row['type'].'&nbsp;&nbsp;</span>';
            }else{
              $value.= '&nbsp;&nbsp;<span class="badge badge-success col-md-0.1">'.$row['type'].'</span>';  
            }
            $value.= "&nbsp;&nbsp;user: ".$row['user'];
            $value.= " ".$row['message']."<br>";
        }
        echo json_encode(['status'=>'success','html'=>$value]);
    }

   // Display last run
    function display_last_run()
    {
        global $db;
        $value = "";
        $query = "select * from settors where setter='last_run'";
        $result = $db->querySingle($query, true);
        if($result){
            $ex = floor(((time() - $result['vals'])/60));
           $value = "Bot Last run: $ex min ago"; 
        }
        echo json_encode(['status'=>'success','html'=>$value]);
    }
    // Get Particular Record
    function get_record()
    {
        global $db;
        $UserID = $_POST['UserID'];
        $query = "select * from parts where id='$UserID'";
        $result = $db->querySingle($query, true);
        echo json_encode($result);
    }

    // Update Function
    function update_value()
    {
        global $db;
        $Update_ID = $_POST['U_UpdateID'];
        $gh_uname = trim($_POST['gh_uname']);
        $gh_mail = trim($_POST['gh_mail']);
        $gh_token = trim($_POST['gh_token']);
        $gh_branch = trim($_POST['gh_branch']);
        $wb_name = trim($_POST['wb_name']);
        $wb_clientid = trim($_POST['wb_clientid']);
        $wb_clientsecret = trim($_POST['wb_clientsecret']);
        $wb_apikey = trim($_POST['wb_apikey']);
        $gh_sitemap_limit = trim($_POST['gh_sitemap_limit']);
        $gh_shedule = trim($_POST['gh_shedule']);
        $wb_shedule = trim($_POST['wb_shedule']);
        $wb_token = trim($_POST['wb_token']);
        $theme_clonned = trim($_POST['theme_clonned']);
        $activated = trim($_POST['activated']);
        $path_moden = trim($_POST['path_mode']);
        $query = "update parts set 
        gh_uname='$gh_uname', 
        gh_mail='$gh_mail', 
        gh_token='$gh_token', 
        gh_branch='$gh_branch',
        wb_name='$wb_name',
        wb_clientid='$wb_clientid',
        wb_clientsecret='$wb_clientsecret',
        wb_apikey='$wb_apikey',
        sitemap_limit=$gh_sitemap_limit,
        gh_shedule=$gh_shedule,
        wb_shedule=$wb_shedule,
        wb_token='$wb_token',
        theme_clonned='$theme_clonned',
        wb_next_execute=0,
        gh_next=0,
        activated=$activated,
        path_mode='$path_moden'
        where id=$Update_ID ";
        $result = $db->exec($query);
        if($result)
        {
            echo ' Your Record Has Been Updated ';
        }
        else
        {
            echo ' Please Check Your Query '.$db->lastErrorMsg();
        }
    }

    function delete_record()
    {
        global $db;
        $Del_Id = $_POST['Del_ID'];
        $Del_un = $_POST['Del_un'];
        if(!empty($Del_Id) && !empty($Del_un)){
            $query = "DELETE FROM parts where id=$Del_Id ";
            $result = $db->exec($query);

            if($result)
            {
                echo ' Your Record Has Been Delete ';
                $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$Del_un','deleted','success',".time().")");
            }
            else
            {
                echo ' Please Check Your Query ';
            }
        }
    }
    function delete_logs()
    {
        global $db;
        $query = "DELETE FROM logs ";
        $result = $db->exec($query);

        if($result)
        {
            echo ' Logs Deleted!!!';
        }
        else
        {
            echo ' Please Check Your Query ';
        }
    }
?>