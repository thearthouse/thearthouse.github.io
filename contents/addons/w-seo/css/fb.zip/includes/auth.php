<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
    header("Content-Type: text/html; charset=utf-8");
}


if (isset($_GET["user"]) && trim($_GET["user"]) !== "") {
    $User = trim($_GET["user"]);
}else{
    die("user not selected");
}
require_once dirname(__FILE__). '/connection.php';
require_once dirname(__FILE__).'/v_google_api/vendor/autoload.php';
date_default_timezone_set('Europe/Istanbul');

/* 
# önemli youtube error berse domain değiştir php 5.6
///cron.php  cron ekle 1 minute
//index.php?cron=cron  debug
# https://console.developers.google.com/project 
1 - Api key olştur
2 - Blogger ve Youtube v3 ve webmaster etkinleştir 
3 - Authorized domains ----  000webhostapp.com
   a- web aplication
   b - redirect url server url example http://***.000webhostapp.com/auth.php
$action = " json name yazmany unutma son 3 - b daki linke git";
Eğer tema Empario bolsa 	"tema": "emp"   dal bolsada "tema": "none"  yaz	
"type": "dm", dailymotion
"type": "yt",	youtube, Youtube bolsa category oluştur	

 /auth.php  auth
 /cron.php  cron
 /index.php?cron=cron  debug
 	
*/
$scriptUri = "https://".$_SERVER["HTTP_HOST"].$_SERVER['PHP_SELF']."?user=$User";
$client = new Google_Client();
$client->setAccessType('offline'); // default: offline
$query = "select * from parts where gh_uname='$User'";
$result = $db->querySingle($query, true);
if($result && !empty($result['wb_name']) && !empty($result['wb_clientid']) && !empty($result['wb_clientsecret']) && !empty($result['wb_apikey'])){
    $client->setApplicationName($result['wb_name']); //name of the application
    $client->setClientId($result['wb_clientid']); //insert your client id
    $client->setClientSecret($result['wb_clientsecret']); //insert your client secret
    $client->setRedirectUri($scriptUri); //redirects to same url
    $client->setDeveloperKey($result['wb_apikey']); // API key (at bottom of page)
    if(strpos($result['theme_clonned'], 'index_fast') !== false){
        $client->setScopes(array('https://www.googleapis.com/auth/webmasters', 'https://www.googleapis.com/auth/indexing'));
    }else{
        $client->setScopes(array('https://www.googleapis.com/auth/webmasters'));  //since we are going to use blogger services
    }
    $client->addScope(Google_Service_Oauth2::USERINFO_EMAIL);
    
}else{
    die("user $User error check main index.php");
}
if (isset($_GET['logout'])) { // logout: destroy token
    unset($_SESSION['token']);
    die('Logged out.');
}
if (isset($_GET['code'])) {
    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
    $tki = json_encode($token);
    $db->exec("update parts set wb_token='$tki' where gh_uname='$User'");
    $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','outh saved','success',".time().")");
    header('Location: ' . filter_var($scriptUri, FILTER_SANITIZE_URL));
}

if (!empty($result['wb_token'])) {
/*     $token = $client->fetchAccessTokenWithAuthCode($result['wb_token']);
    print_r($token);
    $toke = $token["refresh_token"]; */
    $client->setAccessToken($result['wb_token']);
}
if (!$client->getAccessToken()) { // auth call to google
    $client->setApprovalPrompt('force');
    $authUrl = $client->createAuthUrl();
    echo '<span style="color: red;"><b><a href="'.$authUrl.'">Auth</a></b></span>';
    echo "<br><br>add redirect url : $scriptUri <br><br>https://console.developers.google.com/";
    die();
}
    
    
    
    

// webmaster
$firebase_name = strtolower(trim($result['wb_name']));
$data = file_getcontent_with_proxy("https://$firebase_name.web.app/stats.json");
$data = json_decode($data, true);
$data = $data[0];
@$stats_datavid = $data['total_posts'];
$numbers=$stats_datavid/150;
$number=preg_replace('/\.(.+)/', '', $numbers);

$webmastersService = new Google_Service_Webmasters($client);
$sitemaps = $webmastersService->sitemaps;
////$submt = $sitemaps->submit('https://esbizer.blogspot.com/', 'https://esbizer.blogspot.com/sitemap.xml?page=34');
$w_url = "https://$firebase_name.web.app";
$response = $sitemaps->listSitemaps($w_url);
$sites = $webmastersService->sites->listSites();
foreach($sites['siteEntry'] as $sit){
    if(strpos(strtolower($sit['siteUrl']), strtolower($firebase_name)) !== false){
    echo $sit['siteUrl'].'  ok api works<br>';
    }
}
$x = 1;
$smap_leng = 0;
if ( isset($response['sitemap'][0]['path']) && !empty($response['sitemap'][0]['path']) && $stats_datavid >= 150 && $result['sitemap_limit'] >= $result['total_sitemap']) {
    while($x <= $number) {
        $urls = $w_url.'/post-sitemap'.$x.'.xml';
        $urlbes = searchb($response['sitemap'],$urls);
            if ($urlbes == "no"){
                $submt = $sitemaps->submit($w_url, $urls);
                $mssde = "webmaster $urls submitted";
                $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','$mssde','success',".time().")");
            }
        $x++;
    }
        $bnnn = 0;
        foreach($response['sitemap'] as $index=>$val){
            if (isset($val['path'])){
                $bnnn += 1;  
            } 
        }
        $smap_leng = $bnnn;
}else if(empty($response['sitemap'][0]['path'])){
    $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','webmaster can not retrive sitemaps','error',".time().")");
}
    
$u_time = time();
$u_next = time()+($result['wb_shedule']*60);
$db->exec("update parts set wb_last_execute=$u_time,wb_next_execute=$u_next,total_sitemap=$smap_leng where gh_uname='$User'");

function searchb($contarr,$search) { 
    $contfund = "no";
    foreach($contarr as $index=>$val){
        if ($val['path'] == $search){
            $contfund = "yes";  
        } 
    }
    return $contfund ;
}
if(strlen($result['wb_token']) > 3 && strpos($result['theme_clonned'], 'index_fast') !== false && isset($response['sitemap'][0]['path'])){
    
    $client->setConfig( 'base_path', 'https://indexing.googleapis.com' );
    $client->setUseBatch( true );
    // init google batch and set root URL.
    $service = new Google_Service_Indexing( $client );
    $batch   = new Google_Http_Batch( $client, false, 'https://indexing.googleapis.com' );
    $nomap = intval($number)+1;
    $sitemap_URL = "https://$firebase_name.web.app/post-sitemap$nomap.xml";
    $array = json_decode(json_encode(simplexml_load_file($sitemap_URL) ), TRUE);
    foreach($array['url'] as $r){
        $vurl = $r["loc"];
        //echo $vurl."<br>";
        $db->exec("INSERT OR IGNORE INTO urls(url,status) VALUES('$vurl','no')");
    }
    if (isset($array['url'])){
        $db->exec("INSERT OR IGNORE INTO urls(url,status) VALUES('$sitemap_URL','no')");
    }
    $for_like = "$firebase_name.web.app";
    $query = "select * from urls WHERE url LIKE '%".$for_like."%' AND status='no' limit 20";
    $reult = $db->query($query);
    $cols = 0;

    while($row= $reult->fetchArray()){
        $post_body = new Google_Service_Indexing_UrlNotification();
        $gurl = $row["url"];
        $db->exec("update urls set status='ok' where url='$gurl'");
        echo $gurl."<br>";
        $post_body->setType( 'URL_UPDATED' );
        $post_body->setUrl( $gurl );
        $request_part = $service->urlNotifications->publish( $post_body ); // phpcs:ignore
        $batch->add( $request_part, 'url-' . $cols );
        $cols ++;
    }
    echo $cols;
    if ($cols > 0){
        $rests  = $batch->execute();
        $data      = [];
        $res_count = count( $rests );
        foreach ( $rests as $id => $response ) {
            // Change "response-url-1" to "url-1".
            $local_id = substr( $id, 9 );
            if ( is_a( $response, 'Google_Service_Exception' ) ) {
                $data[ $local_id ] = json_decode( $response->getMessage() );
            } else {
                $data[ $local_id ] = (array) $response->toSimpleObject();
            }
            if ( $res_count === 1 ) {
                $data = $data[ $local_id ];
            }
        }
        $data = json_encode($data);
        echo $data;
        file_put_contents("index_api_res.txt",$data);
    }
}
?>