﻿﻿<?php
/* function FilterPermalink($link,$vidid){
	$link = strtolower($link);
	$link = preg_replace("/[^a-z0-9\s-]/", " ", $link);
	$link = trim(preg_replace("/[\s-]+/", " ", $link));
	$link = preg_replace('/\s+/', '-', $link);
    $link = preg_replace('~-+~', '-', $link);
	if(strlen($link) > 40){
		$link = substr($link, 0, strpos($link, '-', 40));
	}
	if(5 > strlen($link)){
		$link = "blog-post";
	}
    $link = preg_replace('~-+~', '-', $link);
    $link = trim($link, '-');
	
return $link;
} */
function FilterPermalink($link,$vidid){
	$link = strtolower($link);
	$link = preg_replace("/[^a-z0-9\s-]/", " ", $link);
	$link = trim(preg_replace("/[\s-]+/", " ", $link));
	$link = preg_replace('/\s+/', '-', $link);
    $link = preg_replace('~-+~', '-', $link);
	if(strlen($link) > 70){
		$link = substr($link, 0, strpos($link, '-', 70));
	}
	if(5 > strlen($link)){
		$link = $vidid;
	}
    $link = preg_replace('~-+~', '-', $link);
    $link = trim($link, '-');
	
return $link;
}
$f_contents = file(dirname(__FILE__)."/eng.txt"); 
$line = $f_contents[rand(0, count($f_contents) - 1)];
$title = urlencode($line);

$pattern = '/"videoId":"(.*?)"/i';
$pattern_yt = '/YouTube/i';
//echo '<br>https://www.youtube.com/results?filters=week&search_sort=video_view_count&search_query='.$title.'<br>';
$content = file_getcontent_with_proxy('https://www.youtube.com/results?filters=week&search_sort=video_view_count&search_query='.$title);
 $tags ="video";
  $tagss ="";
preg_match_all($pattern, $content, $sults);
preg_match_all($pattern_yt, $content, $sults_yt);
$results=array();
foreach(array_unique($sults[1]) as $itim) {
    array_push($results, trim($itim));
}
if(count($results) > 0){
    foreach($results as $item) {
        $videoida = $item;
        if(findinger2($videoida)){break;}
    }
    $check_join = join(",",$results);
    $dapi = file_getcontent_with_proxy("https://ziguas.pserver.ru/bgapp/includes/dapi.php?arr=$check_join");
    $dapi = json_decode($dapi, true);
    if (isset($dapi["add"])){
        $videoida = trim($dapi["add"]);
    }else{
        $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','dapi add returned error ','error',".time().")");
        die("Dapi arr error");
    }
}else{
    $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','$zig video regex error ','error',".time().")");
    //file_put_contents("error_log.txt", $content, FILE_APPEND);
    sleep(10);
    die('<br>video id[regex] empty code f145621');
}
										
findinger($videoida);
require_once dirname(__FILE__).'/cat.php';

$taglist = '';
$videoid = '';
/* id,title,description,tag,image */
$str = file_get_contents('https://www.googleapis.com/youtube/v3/videos?key='.$row['wb_apikey'].'&part=statistics&part=snippet&part=contentDetails&id='.$videoida);
$json = json_decode($str, true);
//echo $str;
if(isset($json['items'][0]['id'])){
    $videoid = trim($json['items'][0]['id']);
} else {
    $videoid = '';
    $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','Youtube api error adding +15 min id: $videoida','error',".time().")");
    $u_next = time()+(1*60);
    $db->exec("update parts set gh_next=$u_next where gh_uname='$User'");
    die('video id empty code fghkl754 id:'.$videoida);   
}
findinger($videoid);
if (isset($json['items'][0]['snippet']['liveBroadcastContent']) && $json['items'][0]['snippet']['liveBroadcastContent'] == "live"){
    $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','live','error',".time().")");
    die('live');  
}
$vidtitle = trim($json['items'][0]['snippet']['title']);
$viddesc = $json['items'][0]['snippet']['description'];
$viewCount  = trim($json['items'][0]['statistics']['viewCount']);
$likeCount  = trim($json['items'][0]['statistics']['likeCount']);
$dislikeCount  = trim($json['items'][0]['statistics']['dislikeCount']);
$vid_date  = trim($json['items'][0]['snippet']['publishedAt']);
$vid_duration  = trim($json['items'][0]['contentDetails']['duration']);
if (3 > strlen($videoid)){
    die('video ld len small than 5');  
}
//echo '<br>this video vies '.$viewCount.'<br>';
$categoryid = $json['items'][0]['snippet']['categoryId'];
$categorys = $categry[$categoryid];
$tags ="";
$tagsdesc ="";
if (!empty($json['items'][0]['snippet']['tags'][0])) {
    ///$tegorys = $json['items'][0]['snippet']['tags'][0];
    $taglist = $json['items'][0]['snippet']['tags'];
    $tagsdesc = join(" ",$taglist);
    $i = 0;
    foreach($taglist as $categorie)
    {
        $tags .=  json_encode($categorie, JSON_UNESCAPED_UNICODE).',';
        if (++$i == 3) break;
    }
} else {
    $tit_to = $json['items'][0]['snippet']['title'];
    $tit_to_tag = explode(" ",$tit_to);
    $i = 0;
    foreach($tit_to_tag as $itiml) {
        if (strlen($itiml) > 4){
            $tags .=  json_encode($itiml, JSON_UNESCAPED_UNICODE).',';
            if (++$i == 3) break;
        }
    }    
}
$viddesc = htmlspecialchars(trim(strip_tags($viddesc)));
$viddesc = preg_replace('~[a-z]+://\S+~','<a rel="nofollow" target="blank" href="$0">$0</a>',$viddesc);
$viddesc = preg_replace('/\r/','picassosesseessseseseseseses',$viddesc);
$viddesc = preg_replace('/\n/','picassosesseessseseseseseses',$viddesc);
$viddesc = str_replace("picassosesseessseseseseseses","<br />",$viddesc);

//channel name image,

$ent = file_getcontent_with_proxy('https://www.youtube.com/oembed?url=http://www.youtube.com/watch?v='.$videoid.'&format=json');
$ent = json_decode($ent, true);
$vidimgson = trim($ent['thumbnail_url']);
$cha_name = trim($ent['author_name']);

$tags = rtrim($tags, ',');	
/* preg_match_all('/index/i', $vidtitle, $engelliler);	if(isset($engelliler[0][0])){die('blocked_word:index');}
preg_match_all('/semalt/i', $vidtitle, $engelliler);if(isset($engelliler[0][0])){die('blocked_word:semalt');}	
preg_match_all('/full/i',$vidtitle,$engelliler);if(isset($engelliler[0][0])){die('blocked_word:full');}
preg_match_all('/season/i',$vidtitle,$engelliler);if(isset($engelliler[0][0])){die('blocked_word:season');}
preg_match_all('/episod/i',$vidtitle,$engelliler);if(isset($engelliler[0][0])){die('blocked_word:episod');}
preg_match_all('/ep /i',$vidtitle,$engelliler);if(isset($engelliler[0][0])){die('blocked_word:episod');}
preg_match_all('/ep\-/i',$vidtitle,$engelliler);if(isset($engelliler[0][0])){die('blocked_word:episod');}
preg_match_all('/ep\:/i',$vidtitle,$engelliler);if(isset($engelliler[0][0])){die('blocked_word:episod');}
preg_match_all('/ep\|/i',$vidtitle,$engelliler);if(isset($engelliler[0][0])){die('blocked_word:episod');}
preg_match_all('/movies/i',$vidtitle,$engelliler);if(isset($engelliler[0][0])){die('blocked_word:episod');}
preg_match_all('/movie/i',$vidtitle,$engelliler);if(isset($engelliler[0][0])){die('blocked_word:episod');}
preg_match_all('/sex/i',$vidtitle,$engelliler);if(isset($engelliler[0][0])){die('blocked_word:episod');}
preg_match_all('/porno/i',$vidtitle,$engelliler);if(isset($engelliler[0][0])){die('blocked_word:episod');} */

//word clean

$badWords = array("5hit","a55","anal","anus","ar5e","arrse","arse","ass","asses","assfukka","asshole.*","b!tch","b00bs","b17ch","b1tch","ballsack","bastard","beastial.*","bestial.*","bi+ch","biatch","bitch.*","blowjob","blowjob","blowjobs","bollock","bollok","boner","bukkake","buceta","butthole","buttmunch","buttplug","c0ck","c0cksucker","carpetmuncher","chink","cl1t","clit","cock","cock-sucker","cockface","cockhead","cockmunch.*","cocks","cocksuck.*","cocksuka","cocksukka","cok","cokmuncher","coksucka","coon","cox","cum","cummer","cumming","cums","cumshot","cunilingus","cunillingus","cunnilingus","cunt","cuntlick.*","cunts","cyalis","cyberfuc","d1ck","dick","dickhead","dirsa","dlck","donkeypunch.*","doosh","duche","dyke","ejaculat.*","ejakulate","fuck","fucker","fag","fagging","faggitt","faggot","faggs","fagot","fagots","fags","fatass","fcuker","fcuking","feck","fecker","felch.*","fellate","fellatio","flange","fleshflute","fook","fooker",".*fuck.*","fudgepacker","fudgepacker","fuk","fuker","fukker","fukkin","fuks","fukwhit","fukwit","fux","fux0r","f_u_c_k","gangbang.*","gaylord","gaysex","goatse","hardcoresex","hell","heshe","hoar","hoare","homo","horniest","horny","hotsex","jack-off","jackoff","jap","jerk-off","jizz","kike","knob","knobead","knobed","knobend","knobhead","knobjocky","kondum","kondums","kum","kummer","kumming","kums","kunilingus","m0f0","m0fo","m45terbate","ma5terb8","ma5terbate","masochist","master-bate","masterb8","masterbat.*","mo-fo","mof0","mofo","muff","mutha","muthafucker","nazi","nigga","niggah","niggas","niggaz","nigger","niggers","nob","nobjokey","nobhead","nobjocky","nobjokey","numbnuts","nutsack","orgasim","orgasims","orgasm","orgasms","p0rn","phonesex","phuck","phuk","phuked","phuking","phukked","phukking","phuks","phuq","pimpis","poop","porn","porno","pornography","pornos","prick","pricks","pube","pusse","pussi","pussies","pussy","pussys","rectum","retard","rimjaw","rimming","sadist","schlong","screwing","scroat","scrote","scrotum","semen","sex","sexy","sh!+","sh!t","sh1t","shemale","shi+","shit","shitdick","shite","shithead","shiting","shitings","shits","shitted","shitter.*","shitting.*","shitty","skank.*","slut","sluts","smegma","smut","snatch","son-of-a-bitch","spic","spunk","s_h_i_t","t1tt1e5","t1tties","tit","tits","titt","tittie5","titties","tittywank","titwank","tosser","tw4t","twat","twathead","twatty","twunt.*","v14gra","viagra","wank.*","whoar",".*whore.*","willies","xrated","xxx","index","semalt","full","season","episod.*","ep","epp","movies","movie","epi");

$matches = array();
$matchFound = preg_match_all(
                "/\b(" . implode($badWords,"|") . ")\b/i", 
                $vidtitle, 
                $matches
              );

if ($matchFound) {
  $words = array_unique($matches[0]);
die("blocked: ".implode(" ",$words));
}
	
//jekyll
if (10 > strlen($viddesc)){
   $viddesc =  $vidtitle." ".$tagsdesc;
}
$now_date = strtotime (date ('Y-m-d H:i:s'));
$db_title = $vidtitle;
$db_content = $viddesc;
$db_seo_url = FilterPermalink($db_title." ".$db_content,$videoid);
$datax = date("c", $now_date);
if ($row['path_mode'] == "html"){
    $mixpath = "0001-01-01-".$db_seo_url.".html";
    $zig .= " html";
}else{
    $mixpath = "0001-01-01-".$db_seo_url.".md";
    $zig .= " md";
}
$mixcontent = '---
title: '.json_encode($db_title, JSON_UNESCAPED_UNICODE).'
image: '.json_encode($vidimgson).'
vid_id: '.json_encode($videoid).'
categories: '.json_encode($categorys, JSON_UNESCAPED_UNICODE).'
tags: ['.$tags.']
date: "'.$datax.'"
vid_date: "'.$vid_date.'"
duration: "'.$vid_duration.'"
viewcount: "'.$viewCount.'"
likeCount: "'.$likeCount.'"
dislikeCount: "'.$dislikeCount.'"
channel: '.json_encode($cha_name, JSON_UNESCAPED_UNICODE).'
---
{% raw %}'.$db_content.'{% endraw %}
';

echo $videoid."<br>";
echo $mixcontent."<br>";
/* echo $mixcontent;*/
//file_put_contents("C:\Program Files\Ampps\www\github_websites\github_yt\yt rtaweb v1/_posts/".$mixpath,$mixcontent); 
?>