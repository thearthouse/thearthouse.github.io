<?php 
require_once dirname(__FILE__). '/connection.php';
$videoid = "LBr7kECsjcQ11";
$dapi = file_getcontent_with_proxy("https://dapi.pserver.ru/?id=$videoid");
$dapi = json_decode($dapi, true);
if (isset($dapi["kleyton"])){
    echo "ADD";
}
if (isset($dapi["tarzan"])){
    echo "BAR"; 
}