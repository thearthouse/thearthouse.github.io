<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
    header("Content-Type: text/html; charset=utf-8");
}
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../login.php");
    exit;
}

?>
<script>setTimeout(function(){window.location.reload(1);}, 1000);</script>
<?php

$fp = fopen('wait.log', 'a');
if(flock($fp, LOCK_EX | LOCK_NB )) {
echo "----><br>";
sleep(3);


    if (isset($_GET["user"]) && trim($_GET["user"]) !== "") {
        $User = trim($_GET["user"]);
    }else{
        die("user not selected");
    }
    require_once dirname(__FILE__). '/connection.php';
    $adirs=array();
    $themedir="rtaweb_themes_v7/rtaweb_v7_blogposting";  //yt2  theme yt  rtaweb_themes_v7/
    /*
rtaweb_v7__sade
rtaweb_v7__sade_no_eng
rtaweb_v7_blogposting
rtaweb_v7_blogposting_no_eng
rtaweb_v7_video
rtaweb_v7_video_no_eng
rtaweb_v7_video_special
    */
    function listFolderFiles($dir){
        global $adirs;
        global $themedir;
        $ffs = scandir($dir);

        unset($ffs[array_search('.', $ffs, true)]);
        unset($ffs[array_search('..', $ffs, true)]);

        // prevent empty ordered elements
        if (count($ffs) < 1)
            return;

        
        foreach($ffs as $ff){
            
            if(is_dir($dir.'/'.$ff)) {
                listFolderFiles($dir.'/'.$ff);
            }else{ 
                $m = str_replace("./".$themedir."/","",$dir.'/'.$ff);
                array_push($adirs,$m);
            }
        }
        
    }
    $query = "select * from parts where gh_uname='$User'";
    $result = $db->querySingle($query, true);
    if($result && strpos($result['theme_clonned'], 'done') === false){
        if(strpos($result['theme_clonned'], 'poster-post') !== false){
            $themedir="rtaweb_themes_v7/rtaweb_v7_blogposting_post";
        }else{
            $themedir="rtaweb_themes_v7/rtaweb_v7_blogposting";
        }
        listFolderFiles('./'.$themedir);

        $theme_files = array_filter($adirs);
        $dt=0;
        $cnt = 0;
        $bvt = 0;
        foreach($theme_files as $fif){
            $query = "select * from parts where gh_uname='$User'";
            $if_fi = $db->querySingle($query, true);
            $if_file_added = $if_fi["theme_clonned"]; 
            $dbi = str_replace($fif.'::','',$if_file_added, $val);
            if($val == 0){
                $data = file_get_contents('./'.$themedir.'/'.$fif);   
                $file_name_path = $fif;

                $file_content = $data;
                $file_content = str_replace("fam4564653215312",strtolower(trim($result['wb_name'])),$file_content);
                $file_content = str_replace("emeraldusurl5464531254333333333135",strtolower(trim($result['wb_name'])),$file_content);
                $file_content = str_replace("emeraldtitlesus",ucfirst(strtolower(trim($result['wb_name']))),$file_content);
                $data_git = array (
                  'message' => substr(hash('sha256', random_bytes(18)), 0, 7),
                  'branch' => $result["gh_branch"],
                  'committer' => 
                  array (
                    'name' => $result["gh_uname"],
                    'email' => $result["gh_mail"],
                  ),
                  'content' => base64_encode($file_content)
                );
                $data_string_git = json_encode($data_git);

                $curl = curl_init();

                curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.github.com/repos/".$result['gh_uname']."/contents/".$file_name_path,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "PUT",
                CURLOPT_POSTFIELDS =>$data_string_git,
                CURLOPT_HTTPHEADER => array(
                "Authorization: Basic ".base64_encode($result['gh_mail'].":".$result['gh_token']),
                "User-Agent: Mozilla/5.0 Chrome",
                "Content-Type: text/plain"
                ),
                ));

                $response = curl_exec($curl);
                curl_close($curl);
                $responsa = json_decode($response, true);
                if(isset($responsa['content']['path'])){
                    $nsti = $if_file_added."".$fif."::\n";
                    $db->exec("update parts set theme_clonned='$nsti' where gh_uname='$User'");
                    echo $fif." added<br>";
                    $cnt += 1;
                    $dt += 1;
                }
                if(isset($responsa['message']) && strpos($responsa['message'], '"sha" wasn\'t supplied') !== false){
                    $nsti = $if_file_added."".$fif."::\n";
                    //$db->exec("update parts set theme_clonned='$nsti' where gh_uname='$User'");
                    echo $fif." exists<br>";
                    $cnt += 1;
                    $dt += 1;
                }
                if ($dt > 7){
                    echo "limit<br>";
                    break;
                }
                 $bvt += 1;
            }
        }
        if ($bvt == 0 && strlen($result['theme_clonned']) > 30){
            echo "repo $User/$User.github.io all done";
            //$db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','github theme clonned. Well done!','success',".time().")");
        }
    } else {
        echo "$User done detected ";
    }


    flock($fp, LOCK_UN);
}else{
    echo "Slow down, cowboy!";
}
fclose($fp);
?>