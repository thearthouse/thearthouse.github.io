<?php
header("Content-Type: text/html; charset=utf-8");
session_start();
date_default_timezone_set('Europe/Istanbul');


?>
<script>setTimeout(function(){window.location.reload(1);}, 5000);</script>
<?php

$fp = fopen('wait.log', 'a');
if(flock($fp, LOCK_EX | LOCK_NB )) {
echo "----><br>";
//sleep(3);
                require_once dirname(__FILE__). '/connection.php';

                $db->exec("INSERT OR IGNORE INTO settors(setter,vals) VALUES('last_run','0')");
                $le_ptime = time();
                $db->exec("update settors set vals='$le_ptime' where setter='last_run'");
                $is_added_new = $db->querySingle("SELECT count(*) FROM parts WHERE theme_clonned LIKE '%done%' AND activated > 0 AND (wb_token is null or wb_token = '') AND 16 > updated_vid");
                if($is_added_new > 0){
                    $query = "select * from parts WHERE theme_clonned LIKE '%done%' AND activated > 0 AND (wb_token is null or wb_token = '') AND 16 > updated_vid ORDER BY RANDOM() limit 1";
                }else{
                    $query = "select * from parts WHERE $le_ptime >= gh_next AND theme_clonned LIKE '%done%' AND activated > 0 AND 40500 > updated_vid AND LENGTH(wb_token) > 10 ORDER BY RANDOM() limit 1";
                }
                $result = $db->query($query);
                while($row= $result->fetchArray()){
                    $User = $row['gh_uname'];
                    $zig = "yt2";
                    require_once dirname(__FILE__). '/yt2.php'; 
                    if(strlen($db_seo_url) > 3 && strlen($videoid) > 3 && strlen($vidimgson) > 3 && strlen($categorys) > 1 && strlen($datax) > 3 && strlen($db_title) > 3 && strlen($tags) > 3 && ($row['wb_next_execute'] > $le_ptime || $row['wb_next_execute'] == 0)){


                        date_default_timezone_set('Europe/Istanbul');
                        // github commit
                        $db->exec("INSERT OR IGNORE INTO vids(vid_id,user) VALUES('$videoid','$User')");
                        if($db->changes() >= 1 ){
/*                             $dapi = file_getcontent_with_proxy("https://dapi.pserver.ru/?id=$videoid");
                            $dapi = json_decode($dapi, true);
                           if (isset($dapi["kleyton"])){ */
                            $file_name_path = '_posts/'.$mixpath;
                            $file_content = $mixcontent;
                            $data_git = array (
                              'message' => substr(hash('sha256', random_bytes(18)), 0, 7),
                              'branch' => $row['gh_branch'],
                              'committer' => 
                              array (
                                'name' => $row['gh_uname'],
                                'email' => $row['gh_mail'],
                              ),
                              'content' => base64_encode($file_content)
                            );
                            $data_string_git = json_encode($data_git);
                            $curl = curl_init();
                            curl_setopt_array($curl, array(
                            CURLOPT_URL => "https://api.github.com/repos/".$row['gh_uname']."/contents/".$file_name_path,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_ENCODING => "",
                            CURLOPT_MAXREDIRS => 10,
                            CURLOPT_TIMEOUT => 30,
                            CURLOPT_FOLLOWLOCATION => true,
                            CURLOPT_SSL_VERIFYPEER => false,
                            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                            CURLOPT_CUSTOMREQUEST => "PUT",
                            CURLOPT_POSTFIELDS =>$data_string_git,
                            CURLOPT_HTTPHEADER => array(
                            "Authorization: Basic ".base64_encode($row['gh_mail'].":".$row['gh_token']),
                            "User-Agent: Mozilla/5.0 Chrome",
                            "Content-Type: text/plain"
                            ),
                            ));
                            $response = curl_exec($curl);
                            curl_close($curl);
                            $responsa = json_decode($response, true);
                            if(isset($responsa['content']['path'])){
                                echo("<br><div><span style=\"color: green; font-size: large;\"><b>Gh post Success</b></span></div>");
                                $u_time = time();
                                $u_next = time()+($row['gh_shedule']*60);
                                $db->exec("update parts set gh_last=$u_time,gh_next=$u_next where gh_uname='$User'");
                                $db->exec("update vids set status='ok' where vid_id='$videoid'");
                                $msds = $zig.' post &nbsp;&nbsp;==>   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"'.$responsa['content']['path'].'"';
                                $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','$msds','success',".time().")");
                            }else{
                                $msds = "$zig cannot post with video id: $videoid --> post path : $file_name_path   --> ".$response;
                                $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','$msds','error',".time().")");
                                $dapi = file_getcontent_with_proxy("https://ziguas.pserver.ru/bgapp/includes/dapi.php?del=$videoid");
                            }
                            /* }else{
                                $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','video id tarzan found ','error',".time().")");
                            } */
                        }else{
                            $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','video id insert error db->changes ','error',".time().")");
                        }    
                    }
                    $videos_id_total = $db->querySingle("SELECT count(*) FROM vids WHERE user = '$User'");
                    $videos_id_total_update = $db->querySingle("SELECT count(*) FROM vids WHERE (status != '' OR status IS NOT NULL) AND user = '$User'");
                    $db->exec("update parts set total_vid=$videos_id_total,updated_vid=$videos_id_total_update where gh_uname='$User'");
                    //try submit sitemap
                    if( $le_ptime >= $row['wb_next_execute'] && !empty($row['wb_token']) ){
/*                         $scriptUri = "http://".$_SERVER["HTTP_HOST"].$_SERVER['PHP_SELF'];
                        $wbmurld = str_replace("index.php", "auth.php?user=".$row['gh_uname'],$scriptUri);
                        $data = file_getcontent_with_proxy($wbmurld);
                        echo $data; */
                        function include_auth ($user) {
                            global $db;
                            $_GET["user"] = $user;
                            require_once dirname(__FILE__). '/auth.php';
                        }
                        include_auth($row['gh_uname']);
                    }

                }

sleep(3);
    flock($fp, LOCK_UN);
}else{
    echo "Slow down, cowboy!";
}
fclose($fp);
?>