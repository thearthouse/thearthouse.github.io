<?php 

        require_once('includes/functions.php');
        delete_record();

?>