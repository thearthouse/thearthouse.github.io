<?php 
require_once('includes/functions.php');
    
    display_record();

?>