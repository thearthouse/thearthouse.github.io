<?php 

    require_once('includes/functions.php');
    update_value();

?>