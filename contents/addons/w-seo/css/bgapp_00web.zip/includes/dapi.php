<?php 
//die("Maintenance");
require_once dirname(__FILE__). '/connection.php';
header('Content-type: application/json');
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
date_default_timezone_set('Europe/Istanbul');
$current_unix_time_stamp = time(); // the current date 

$data = [ 'error' => 'error'];
if(isset($_GET["id"]) && strlen($_GET["id"]) > 0){
    $videoid = trim($_GET["id"]);
    $db->exec("INSERT OR IGNORE INTO vids(vid_id) VALUES('$videoid')");
    if($db->changes() >= 1 ){
        $data = [ 'kleyton' => 'done'];
        echo json_encode( $data );
    }else{
        $data = [ 'tarzan' => 'bar'];
        echo json_encode( $data );
    }
}
if(isset($_GET["arr"])){
    $arram = trim($_GET["arr"]);
    $plode = explode(",",$arram);
    $linksArray = array_filter($plode);
    if(count($linksArray) > 0){
        foreach($linksArray as $item) {
            $bitem = trim($item);
            $db->exec("INSERT OR IGNORE INTO vids(vid_id) VALUES('$bitem')");
            if($db->changes() >= 1 ){
                $data = [ 'add' => $bitem];
                break;
            }
        }
    }
    echo json_encode( $data );
}
if(!isset($_GET["id"]) && !isset($_GET["arr"])){
    $videos_id_total = $db->querySingle("SELECT count(*) FROM vids");
    $data = [ 'Total data' => number_format($videos_id_total,0)];
    echo json_encode( $data );
}
?>