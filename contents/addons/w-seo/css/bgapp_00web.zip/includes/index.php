<?php
header("Content-Type: text/html; charset=utf-8");
session_start();
date_default_timezone_set('Europe/Istanbul');

if($_GET["debug"]){
//apps script cron
//die();
$objDateTime = new DateTime('NOW');	
$commenttator = $objDateTime->format('c').' - '.$_GET["debug"]."\n";
//file_put_contents("cron_logs.txt", $commenttator, FILE_APPEND);
}
///die();
///$scfer55555555 = @file_get_contents('http://ziguas.pserver.ru/fllprog/index.php');

$fp = fopen('wait.log', 'a');
if(flock($fp, LOCK_EX | LOCK_NB )) {
echo "----><br>";
//sleep(3);
                require_once dirname(__FILE__). '/connection.php';
                require_once dirname(__FILE__).'/v_google_api/vendor/autoload.php';
                $db->exec("INSERT OR IGNORE INTO settors(setter,vals) VALUES('last_run','0')");
                $le_ptime = time();
                $db->exec("update settors set vals='$le_ptime' where setter='last_run'");
        //     SELECT count(*) FROM parts WHERE theme_clonned LIKE '%boost%' AND $le_ptime >= gh_next AND activated > 0 AND wb_token is not null AND wb_token != '' AND 16 > updated_vid   
       $is_added_new = $db->querySingle("SELECT count(*) FROM parts WHERE $le_ptime >= gh_next AND theme_clonned LIKE '%boost%' AND activated > 0 AND wb_token is not null AND wb_token != '' AND 16 > updated_vid");
                if($is_added_new > 0){
                    //select * FROM parts WHERE theme_clonned LIKE '%boost%' AND $le_ptime >= gh_next AND activated > 0 AND wb_token is not null AND wb_token != '' AND 16 > updated_vid ORDER BY RANDOM() limit 1
                    $query = "select * FROM parts WHERE $le_ptime >= gh_next AND theme_clonned LIKE '%boost%' AND activated > 0 AND wb_token is not null AND wb_token != '' AND 16 > updated_vid ORDER BY RANDOM() limit 1";
                }else{
                    $query = "select * from parts WHERE $le_ptime >= gh_next AND activated > 0 AND wb_token is not null AND wb_token != '' ORDER BY RANDOM() limit 1";
                }
                
                
                $result = $db->query($query);
                while($row= $result->fetchArray()){
                    $User = $row['gh_uname'];
                    $zig = "";
                    if(strpos($row['path_mode'], 'html') !== false){
                        $zig = "html_post_yt";
                       require_once dirname(__FILE__). '/yt.php'; 
                    }else{
                        $zig = "Api_post_yt2";
                        require_once dirname(__FILE__). '/yt2.php';  
                    }
                    if(strlen($db_seo_url) > 3 && strlen($videoid) > 3 && strlen($vidimgson) > 3 && strlen($categorys) > 1 && strlen($mixcontent) > 3 && strlen($db_title) > 3 && strlen($tags) > 3 && ($row['wb_next_execute'] > $le_ptime || $row['wb_next_execute'] == 0)){
                        
                        $commentnumber = '"'.$videoid.'"'.",   ".$db_title."\n";
                        file_put_contents("for_fly.txt", $commentnumber, FILE_APPEND);
                        date_default_timezone_set('Europe/Istanbul');
                        // github commit
                        $db->exec("INSERT OR IGNORE INTO vids(vid_id,user) VALUES('$videoid','$User')");
                        if($db->changes() >= 1 ){
                            
                            $scriptUri = "https://".$_SERVER["HTTP_HOST"].$_SERVER['PHP_SELF'];
                            $client = new Google_Client();
                            $client->setAccessType('offline'); // default: offline
                            $client->setApplicationName($row['wb_name']); //name of the application
                            $client->setClientId($row['wb_clientid']); //insert your client id
                            $client->setClientSecret($row['wb_clientsecret']); //insert your client secret
                            $client->setRedirectUri($scriptUri); //redirects to same url
                            $client->setDeveloperKey($row['wb_apikey']); // API key (at bottom of page)
                            if(strpos($row['theme_clonned'], 'no_sch') !== false){
                                $client->setScopes(array('https://www.googleapis.com/auth/blogger'));  //since we are going to use blogger services
                            }else{
                                $client->setScopes(array('https://www.googleapis.com/auth/blogger', 'https://www.googleapis.com/auth/webmasters'));  //since we are going to use blogger services
                            }
                            //$client->addScope(Google_Service_Oauth2::USERINFO_EMAIL);
                            if (!empty($row['wb_token'])) {
                                $client->setAccessToken($row['wb_token']);
                            }  
                            $tspost = true;
                            $blogger = new Google_Service_Blogger($client);               
                            $mypost = new Google_Service_Blogger_Post();
                            if(strpos($row['path_mode'], 'html') !== false){
                                $mypost->setTitle($db_title);
                                $mypost->setContent($vidpost);
                                if(strpos($row['theme_clonned'], 'no_tags') == false){
                                    $mypost->setLabels([$categorys]);
                                }
                                ///setPublished($date);
                            }else{
                                $mypost->setTitle($db_title);
                                $mypost->setContent($mixcontent); 
                            }
                            try {
                                $data = $blogger->posts->insert($row['gh_token'], $mypost); //post id needs here - put your blogger blog id
                            }
                            catch(Exception $e) {
                              echo '<br>Message: ' .$e->getMessage().'<br>';
                              if (strpos($e->getMessage(), "rateLimitExceeded") !== false){ 
                                    $zsleeper = "+30 min";
                                    $u_next = time()+(30*60);
                                    if($is_added_new > 0){
                                        $u_next = time()+20;
                                        $zsleeper = "+1 min boost includes";
                                    }
                                    $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','Blogger Rate Limit Exceeded $zsleeper','error',".time().")");
                                    $db->exec("update parts set gh_next=$u_next where gh_uname='$User'");
                                    $db->exec("DELETE FROM vids where vid_id='$videoid'");
                                    $tspost = false;
                                    $dapi = file_getcontent_with_proxy("https://ziguas.pserver.ru/bgapp/includes/dapi.php?del=$videoid");
                                }
                            }    
                            if($tspost){                            
                                if(isset($data['url']) || $data['status'] == "LIVE"){
                                    echo("<br><div><span style=\"color: green; font-size: large;\"><b>BG post Success</b></span></div>");
                                    $u_time = time();
                                    $u_next = time()+($row['gh_shedule']*60);
                                    if($is_added_new > 0){
                                       $u_next = time()+20;
                                    }
                                    $db->exec("update parts set gh_last=$u_time,gh_next=$u_next where gh_uname='$User'");
                                    $db->exec("update vids set status='ok' where vid_id='$videoid'");
                                    $db->exec("update vids set status='ok' where vid_id='$videoid'");
                                    $msds = $zig.' &nbsp;&nbsp;==>   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"'.str_replace("http:","https:",$data['url']).'" &nbsp;"'.$videoid .'"';
                                    $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','$msds','success',".time().")");
                                }else{
                                    $msds = "$zig cannot post with video id: $videoid --> ".json_encode($data);
                                    $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','$msds','error',".time().")");
                                } 
                            }                            
                            ///blogger
                        }else{
                            $db->exec("INSERT INTO logs(id,user,message,type,date) values(null,'$User','video id insert error db->changes ','error',".time().")");
                        }    
                    }
                    $videos_id_total = $db->querySingle("SELECT count(*) FROM vids WHERE user = '$User'");
                    $videos_id_total_update = $db->querySingle("SELECT count(*) FROM vids WHERE (status != '' OR status IS NOT NULL) AND user = '$User'");
                    $db->exec("update parts set total_vid=$videos_id_total,updated_vid=$videos_id_total_update where gh_uname='$User'");
                    //try submit sitemap
                    if( $le_ptime >= $row['wb_next_execute'] && !empty($row['wb_token']) && strpos($row['theme_clonned'], 'no_sch') == false ){
/*                         $scriptUri = "http://".$_SERVER["HTTP_HOST"].$_SERVER['PHP_SELF'];
                        $wbmurld = str_replace("index.php", "auth.php?user=".$row['gh_uname'],$scriptUri);
                        $data = file_getcontent_with_proxy($wbmurld);
                        echo $data; */
                        function include_auth ($user) {
                            global $db;
                            $_GET["user"] = $user;
                            require_once dirname(__FILE__). '/auth.php';
                        }
                        include_auth($row['gh_uname']);
                    }

                }
$db->close();
sleep(1);
    flock($fp, LOCK_UN);
}else{
    echo "Slow down, cowboy!";
}
fclose($fp);
?>