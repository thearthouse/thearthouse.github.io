<?php 
//die("Maintenance");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('Europe/Istanbul');
$current_unix_time_stamp = time(); // the current date 
$db = new SQLite3(dirname(__FILE__).'/data.db') or die("cannot open the database");
$db->busyTimeout(60000);
$db->exec('PRAGMA journal_mode = wal;');

$db->exec('CREATE TABLE IF NOT EXISTS parts (
id INTEGER PRIMARY KEY, 
gh_uname text UNIQUE, 
gh_mail text,
gh_token text UNIQUE, 
wb_name text,
wb_clientid text,
wb_clientsecret text,
wb_apikey text,
wb_token text,
wb_shedule INTEGER, 
gh_shedule INTEGER,
sitemap_limit INTEGER, 
gh_last INTEGER,
gh_next INTEGER,
wb_last_execute INTEGER,
wb_next_execute INTEGER,
theme_clonned text,
total_sitemap INTEGER,
activated INTEGER,
total_vid INTEGER DEFAULT 0,
updated_vid INTEGER DEFAULT 0,
path_mode text
);');

$db->exec('CREATE TABLE IF NOT EXISTS vids (
id INTEGER PRIMARY KEY, 
vid_id text UNIQUE, 
user text,
status text
);');

$db->exec('CREATE TABLE IF NOT EXISTS logs (
id INTEGER PRIMARY KEY, 
user text,
message text, 
type text,
date INTEGER
);');
$db->exec('CREATE TABLE IF NOT EXISTS settors (
id INTEGER PRIMARY KEY, 
setter text UNIQUE,
vals text
);');

/* $db->exec('alter table parts add column total_vid INTEGER DEFAULT 0');
$db->exec('alter table parts add column updated_vid INTEGER DEFAULT 0'); */
//$db->exec('alter table parts add column path_mode text DEFAULT "html"');
function file_getcontent_with_proxy ($urltoget) {
    $url = $urltoget;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // read more about HTTPS 
    curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36.');
    $curl_scraped_page = curl_exec($ch);
    curl_close($ch);
    return $curl_scraped_page;
}

function findinger($id) {
    global $db;
    $db->exec("UPDATE vids SET vid_id = '$id' WHERE vid_id = '$id';");
    if($db->changes() >= 1){
      die("video id found");  
    }
}
function findinger2($id) {
    global $db;
    $res = true;
    $db->exec("UPDATE vids SET vid_id = '$id' WHERE vid_id = '$id';");
    if($db->changes() >= 1){
      $res = false; 
    }
    return $res;
}
function escape($str){
    $gh = htmlspecialchars_decode ($str,ENT_QUOTES);
    return htmlspecialchars($gh, ENT_QUOTES | ENT_SUBSTITUTE | ENT_XML1, "UTF-8");
}

function escape_with_html($str){
    $gh = html_entity_decode ($str,ENT_QUOTES);
    return htmlentities($gh, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");
}
?>