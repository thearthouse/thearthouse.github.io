$(document).ready(function()
{
    Insert_record();
    view_record();
    get_record();
    update_record();
    delete_record();
    delete_logs();
    setInterval(async () => {
        try { 
            view_record();     
        } catch (e) {
            console.error(e);
        }
    }, 10000);
})

// Insert Record in the Database
function Insert_record()
{
   $(document).on('click','#btn_register',function()
   {
        var gh_uname_add = $('#gh_uname_add').val();
        var gh_mail_add = $('#gh_mail_add').val();
        var gh_token_add = $('#gh_token_add').val();
        var wb_name_add = $('#wb_name_add').val();
        var wb_clientid_add = $('#wb_clientid_add').val();
        var wb_clientsecret_add = $('#wb_clientsecret_add').val();
        var wb_apikey_add = $('#wb_apikey_add').val();
        var gh_sitemap_limit_add = $('#gh_sitemap_limit_add').val();
        var gh_shedule_add = $('#gh_shedule_add').val();
        var wb_shedule_add = $('#wb_shedule_add').val();
        var path_mode_add = $('#path_mode').val();
        if(gh_uname_add == "" || gh_mail_add == "" || gh_token_add =="" || gh_sitemap_limit_add =="" || gh_shedule_add == "" || wb_shedule_add =="" || wb_apikey_add =="")
        {
            $('#message').html('please Fill in the Blanks').css({'color' : 'red','font-weight': '820'});
        }
        else
        {
            $.ajax(
                {
                    url : 'insert.php',
                    method: 'post',
                    data:{
                        gh_uname:gh_uname_add,
                        gh_mail:gh_mail_add,
                        gh_token:gh_token_add,
                        wb_name:wb_name_add,
                        wb_clientid:wb_clientid_add,
                        wb_clientsecret:wb_clientsecret_add,
                        wb_apikey:wb_apikey_add,
                        gh_sitemap_limit:gh_sitemap_limit_add,
                        gh_shedule:gh_shedule_add,
                        wb_shedule:wb_shedule_add,
                        path_mode:path_mode_add
                        },
                    success: function(data)
                    {
                        $('#message').html(data).css({'font-weight': '820'});
                        $('#Registration').modal('show');
                        //$('form').trigger('reset');
                        view_record();
                    }
                    
                })
        }
        
   })

   $(document).on('click','#btn_close',function()
   {
       $('form').trigger('reset');
       $('#message').html('');
       $('#up-message').html('');
   })   
}

// Display Record
function view_record()
{
        if($("#vehicle1").prop('checked') == false){
            var man_select = $('#man_select').val();
            $.ajax(
                {
                    url: 'view.php',
                    method: 'post',
                    data:{man_select:man_select},
                    success: function(data)
                    {
                        data = $.parseJSON(data);
                        if(data.status=='success')
                        {
                            $('#table').html(data.html);
                        }
                    }
                })
        }else{
            console.log("view_record() paused");
        }

        var logs_opt = $('#logs_opt').val();
        $.ajax(
        {
            url: 'logs.php',
            method: 'post',
            data:{logger:logs_opt},
            success: function(data)
            {
                data = $.parseJSON(data);
                if(data.status=='success')
                {
                    $('#loggerd').html(data.html);
                }
            }
        })
        
        $.ajax(
        {
            url: 'get_last_run.php',
            method: 'post',
            success: function(data)
            {
                data = $.parseJSON(data);
                if(data.status=='success')
                {
                    $('#botrunned').html(data.html);
                }
            }
        })
}

//Get Particular Record
function get_record()
{
    $(document).on('click','#btn_edit',function()
    {
        var ID = $(this).attr('data-id');
        $.ajax(
            {
                url: 'get_data.php',
                method: 'post',
                data:{UserID:ID},
                dataType: 'JSON',
                success: function(data)
                {
                   $('#Up_User_ID').val(data['id']);
                   $('#gh_uname_edit').val(data['gh_uname']);
                   $('#gh_mail_edit').val(data['gh_mail']);
                   $('#gh_token_edit').val(data['gh_token']);
                   $('#wb_name_edit').val(data['wb_name']);
                   $('#wb_clientid_edit').val(data['wb_clientid']);
                   $('#wb_clientsecret_edit').val(data['wb_clientsecret']);
                   $('#wb_apikey_edit').val(data['wb_apikey']);
                   $('#gh_sitemap_limit_edit').val(data['sitemap_limit']);
                   $('#gh_shedule_edit').val(data['gh_shedule']);
                   $('#wb_shedule_edit').val(data['wb_shedule']);
                   $('#wb_token_edit').val(data['wb_token']);
                   $('#theme_clonned_edit').val(data['theme_clonned']);
                   $('#activated_edit').val(data['activated']);
                   $('#path_mode_edit').val(data['path_mode']);
                   $('#update').modal('show');
                   
                }
                
            })
    })
}

// Update Record 
function update_record()
{
    
    $(document).on('click','#btn_update',function()
    {
        
        var UpdateID = $('#Up_User_ID').val();
        var gh_uname_edit = $('#gh_uname_edit').val();
        var gh_mail_edit = $('#gh_mail_edit').val();
        var gh_token_edit = $('#gh_token_edit').val();
        var wb_name_edit = $('#wb_name_edit').val();
        var wb_clientid_edit = $('#wb_clientid_edit').val();
        var wb_clientsecret_edit = $('#wb_clientsecret_edit').val();
        var wb_apikey_edit = $('#wb_apikey_edit').val();
        var gh_sitemap_limit_edit = $('#gh_sitemap_limit_edit').val();
        var gh_shedule_edit = $('#gh_shedule_edit').val();
        var wb_shedule_edit = $('#wb_shedule_edit').val();
        var wb_token_edit = $('#wb_token_edit').val();
        var theme_clonned_edit = $('#theme_clonned_edit').val();
        var activated_edit = $('#activated_edit').val();
        var path_mode_edit = $('#path_mode_edit').val();
        if(gh_uname_edit == "" || gh_mail_edit == "" || gh_token_edit == "" || wb_name_edit == ""|| wb_clientid_edit == "" || wb_clientsecret_edit == ""|| wb_apikey_edit == "" || gh_sitemap_limit_edit == ""|| gh_shedule_edit == "" || wb_shedule_edit == "" || activated_edit == "")
        {
            $('#up-message').html('please Fill in the Blanks').css({'color' : 'red','font-weight': '820'});
            $('#update').modal('show');
        }
        else
        {
            $.ajax(
                {
                    url: 'update.php',
                    method: 'post',
                    data:{
                        U_UpdateID:UpdateID,
                        gh_uname:gh_uname_edit,
                        gh_mail:gh_mail_edit,
                        gh_token:gh_token_edit,
                        wb_name:wb_name_edit,
                        wb_clientid:wb_clientid_edit,
                        wb_clientsecret:wb_clientsecret_edit,
                        wb_apikey:wb_apikey_edit,
                        gh_sitemap_limit:gh_sitemap_limit_edit,
                        gh_shedule:gh_shedule_edit,
                        wb_shedule:wb_shedule_edit,
                        wb_token:wb_token_edit,
                        theme_clonned:theme_clonned_edit,
                        activated:activated_edit,
                        path_mode:path_mode_edit
                        },
                    success: function(data)
                    {
                        $('#up-message').html(data).css({'color' : 'green','font-weight': '820'});
                        $('#update').modal('show');
                        view_record();
                    }
                })
        }
        
    })
}

// Delete Function
function delete_record()
{
    $(document).on('click','#btn_delete',function()
    {
        var Delete_ID = $(this).attr('data-id1');
        var Delete_un = $(this).attr('data-id2');
        $('#delete').modal('show');
        $('#delete-message').html('');
        $('#btn_delete_record').show();
        $('#drmmuss').show();
        $('#drmmuss').html('Do You Want to Delete the Record '+Delete_un+' ?');
        $(document).one('click','#btn_delete_record',function()
        {
            $.ajax(
                {
                    url: 'delete.php',
                    method: 'post',
                    data:{Del_ID:Delete_ID,Del_un:Delete_un},
                    success: function(data)
                    {
                        $('#delete-message').html(data).css({'color' : 'red','font-weight': '820'});
                        $('#btn_delete_record').hide();
                        $('#drmmuss').hide();
                        $('#delete').modal('show');
                        view_record();
                    }
                })
        })
    })
}

// Delete logs
function delete_logs()
{
     $(document).on('click','#btn_delete_logs',function()
        {
            $.ajax(
                {
                    url: 'del_logs.php',
                    method: 'post',
                    data:{Del_ID:'truc'},
                    success: function(data)
                    {
                        $("#logskaz").removeClass('d-none');
                        $('#logskaz').html('<strong><span class="text-success">'+data+'</span></strong>');
                        view_record();
                        setTimeout(function() {
                            $("#logskaz").addClass('d-none');
                        }, 2000);
                    }
                })
        })
}



